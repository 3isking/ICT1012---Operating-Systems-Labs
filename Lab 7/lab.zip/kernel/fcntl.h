#define O_RDONLY  0x000
#define O_WRONLY  0x001
#define O_RDWR    0x002
#define O_CREATE  0x200
#define O_TRUNC   0x400

// ICT1012 Lab 4 ----------------
// mmap protection flags
#define PROT_NONE   0x0
#define PROT_READ   0x1
#define PROT_WRITE  0x2
#define PROT_EXEC   0x4

// mmap mapping flags
#define MAP_SHARED  0x01
#define MAP_PRIVATE 0x02
//-------------------------------