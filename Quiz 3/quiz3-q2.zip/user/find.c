#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

// Helper to get the filename from a path (e.g., "a/b/c" -> "c")
char* fmtname(char *path) {
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
    ;
  p++;

  // Return the name without padding
  if(strlen(p) >= DIRSIZ)
    return p;
  
  memmove(buf, p, strlen(p));
  buf[strlen(p)] = 0; 
  return buf;
}

void find(char *path, char *target) {
  
}

int main(int argc, char *argv[]) {
  if(argc != 3){
    fprintf(2, "Usage: find <path> <filename>\n");
    exit(1);
  }
  find(argv[1], argv[2]);
  exit(0);
}